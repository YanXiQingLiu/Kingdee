#!/bin/sh
#===============================================================================
# SCRIPT    : os.sh
# AUTHOR    : pound_wu
# Date      : 2011-10-31
# REV       : 1.2
# PLATFORM  : AIX HPUX Linux Solaris I5/OS(OS400)
# PURPOSE   : This script is used for collect EAS environment information.
# 
# Copyright(c) 1993-2011 Kingdee Co.,Ltd.
# All Rights Reserved 
#===============================================================================
OS_PLATFORM=`uname -s`

OLD_LANG=$LANG
LANG=en
export LANG


#*******************************************************************************
# Common functions               
#*******************************************************************************
SUPPORTTYPE=NORMAL


#CMD_CURRENT_DIR=`pwd`
#SUPPORTDIR=$CMD_CURRENT_DIR/eassupport

#mkdir -p $SUPPORTDIR/OS

#cd $SUPPORTDIR

if [ -f admin.sh ] 
then
  cd diag/eassupport
else
  cd eassupport
fi
   
 
  if [ $OS_PLATFORM != "OS400" ]
  then
  	echo "Execute: ulimit -a"                                                           >> OS/limits
  	                ulimit -a                                                           >> OS/limits
  fi
  
  echo Execute: whoami                                                                  >> OS/whoami
  if [ $OS_PLATFORM = "HP-UX" -o $OS_PLATFORM = "Linux" ]
  then
      /usr/bin/whoami                                                                   >> OS/whoami 2>&1
  elif [ $OS_PLATFORM = "AIX" ]
  then    
      /usr/bin/whoami                                                                   >> OS/whoami 2>&1
  else
      /usr/ucb/whoami                                                                   >> OS/whoami 2>&1
  fi
  
  PATHdmesg=`which dmesg`
  if [ 0 = $? ]
  then
     echo Execute: $PATHdmesg                                         >> OS/dmesg
                   $PATHdmesg                                         >> OS/dmesg
  elif [ -x /sbin/dmesg ]
  then
     echo Execute: /sbin/dmesg                                        >> OS/dmesg
                   /sbin/dmesg                                        >> OS/dmesg
  elif [ -x /usr/sbin/dmesg ]
  then
     echo Execute: /usr/sbin/dmesg                                    >> OS/dmesg
                   /usr/sbin/dmesg                                    >> OS/dmesg
  elif [ -x /bin/dmesg ]
  then
     echo Execute: /bin/dmesg                                         >> OS/dmesg
                   /bin/dmesg                                         >> OS/dmesg                             
  else
    echo dmesg - did not find the command /usr/sbin or /sbin nor /bin>> OS/dmesg
  fi
  
  PATHlsof=`which lsof`
  if [ 0 = $? ]
  then
     echo Execute: $PATHlsof -n                                         >> OS/lsof
                   $PATHlsof -n                                         >> OS/lsof
  elif [ -x /sbin/lsof ]
  then
     echo Execute: /sbin/lsof -n                                        >> OS/lsof
                   /sbin/lsof -n                                        >> OS/lsof
  elif [ -x /usr/sbin/lsof ]
  then
     echo Execute: /usr/sbin/lsof -n                                    >> OS/lsof
                   /usr/sbin/lsof -n                                    >> OS/lsof
  elif [ -x /bin/lsof ]
  then
     echo Execute: /bin/lsof -n                                         >> OS/lsof
                   /bin/lsof -n                                         >> OS/lsof
  elif [ -x /usr/local/bin/lsof ]
  then
     echo Execute: /usr/local/bin/lsof -n                               >> OS/lsof
                   /usr/local/bin/lsof -n                               >> OS/lsof                             
  else
    echo lsof - did not find the command /usr/sbin or /sbin or /bin nor /usr/local/bin >> OS/lsof
  fi
  
  if [ $OS_PLATFORM = "HP-UX" ]
  then
  	echo Execute: getconf ARG_MAX                                      >> OS/getconf
    	            getconf ARG_MAX                                      >> OS/getconf
  	echo Execute: getconf CHAR_BIT                                      >> OS/getconf
    	            getconf CHAR_BIT                                      >> OS/getconf
  	echo Execute: getconf CHAR_MAX                                      >> OS/getconf
    	            getconf CHAR_MAX                                      >> OS/getconf   	    
  	echo Execute: getconf CHAR_MIN                                      >> OS/getconf
    	            getconf CHAR_MIN                                      >> OS/getconf   
  	echo Execute: getconf CHILD_MAX                                      >> OS/getconf
    	            getconf CHILD_MAX                                      >> OS/getconf   	            	                      
  	echo Execute: getconf CLK_TCK                                      >> OS/getconf
    	            getconf CLK_TCK                                      >> OS/getconf 
  	echo Execute: getconf COLL_WEIGHTS_MAX                                      >> OS/getconf
    	            getconf COLL_WEIGHTS_MAX                                      >> OS/getconf  	  
  	echo Execute: getconf CPU_CHIP_TYPE                                      >> OS/getconf
    	            getconf CPU_CHIP_TYPE                                      >> OS/getconf   
  	echo Execute: getconf CS_MACHINE_IDENT                                      >> OS/getconf
    	            getconf CS_MACHINE_IDENT                                      >> OS/getconf  
  	echo Execute: getconf CS_PARTITION_IDENT                                      >> OS/getconf
    	            getconf CS_PARTITION_IDENT                                      >> OS/getconf  
  	echo Execute: getconf CS_PATH                                      >> OS/getconf
    	            getconf CS_PATH                                      >> OS/getconf  	
  	echo Execute: getconf CS_MACHINE_SERIAL                                      >> OS/getconf
    	            getconf CS_MACHINE_SERIAL                                      >> OS/getconf
  	echo Execute: getconf EXPR_NEST_MAX                                      >> OS/getconf
    	            getconf EXPR_NEST_MAX                                      >> OS/getconf
  	echo Execute: getconf HW_CPU_SUPP_BITS                                      >> OS/getconf
    	            getconf HW_CPU_SUPP_BITS                                      >> OS/getconf 
  	echo Execute: getconf HW_32_64_CAPABLE                                      >> OS/getconf
    	            getconf HW_32_64_CAPABLE                                      >> OS/getconf
  	echo Execute: getconf KERNEL_BITS                                      >> OS/getconf
    	            getconf KERNEL_BITS                                      >> OS/getconf 
  	echo Execute: getconf INT_MAX                                      >> OS/getconf
    	            getconf INT_MAX                                      >> OS/getconf  	
  	echo Execute: getconf INT_MIN                                      >> OS/getconf
    	            getconf INT_MIN                                      >> OS/getconf
  	echo Execute: getconf MACHINE_MODEL                                      >> OS/getconf
    	            getconf MACHINE_MODEL                                      >> OS/getconf  
  	echo Execute: getconf NL_ARGMAX                                      >> OS/getconf
    	            getconf NL_ARGMAX                                      >> OS/getconf
  	echo Execute: getconf NL_LANGMAX                                      >> OS/getconf
    	            getconf NL_LANGMAX                                      >> OS/getconf  	              	            	              	                         	              	             	              	              	                        	             	            	                      	           
  	echo Execute: getconf NL_NMAX                                      >> OS/getconf
    	            getconf NL_NMAX                                      >> OS/getconf
  	echo Execute: getconf OPEN_MAX                                      >> OS/getconf
    	            getconf OPEN_MAX                                      >> OS/getconf 
  	echo Execute: getconf PATH                                      >> OS/getconf
    	            getconf PATH                                      >> OS/getconf 
  	echo Execute: getconf _POSIX_ARG_MAX                                      >> OS/getconf
    	            getconf _POSIX_ARG_MAX                                      >> OS/getconf  	
  	echo Execute: getconf _POSIX_OPEN_MAX                                      >> OS/getconf
    	            getconf _POSIX_OPEN_MAX                                      >> OS/getconf  
  	echo Execute: getconf _POSIX_TZNAME_MAX                                      >> OS/getconf
    	            getconf _POSIX_TZNAME_MAX                                      >> OS/getconf   	  
  	echo Execute: getconf _POSIX_VERSION                                      >> OS/getconf
    	            getconf _POSIX_VERSION                                      >> OS/getconf 
  	echo Execute: getconf POSIX_ARG_MAX                                      >> OS/getconf
    	            getconf POSIX_ARG_MAX                                      >> OS/getconf 
  	echo Execute: getconf POSIX_OPEN_MAX                                      >> OS/getconf
    	            getconf POSIX_OPEN_MAX                                      >> OS/getconf 
  	echo Execute: getconf WORD_BIT                                      >> OS/getconf
    	            getconf WORD_BIT                                      >> OS/getconf
  	echo Execute: getconf MACHINE_SERIAL                                      >> OS/getconf
    	            getconf MACHINE_SERIAL                                      >> OS/getconf  	              	            	             	             	             	                      	                        	             	              	            
  else
    echo Execute: getconf -a                                      >> OS/getconf
    	            getconf -a                                      >> OS/getconf
  fi
  
  crontab -l >> OS/crontab
  
  uptime >> OS/uptime


LANG=$OLD_LANG
export LANG
