#!/bin/sh
#===============================================================================
# SCRIPT    : os.sh
# AUTHOR    : pound_wu
# Date      : 2011-10-31
# REV       : 1.2
# PLATFORM  : AIX HPUX Linux Solaris I5/OS(OS400)
# PURPOSE   : This script is used for collect EAS environment information.
# 
# Copyright(c) 1993-2011 Kingdee Co.,Ltd.
# All Rights Reserved 
#===============================================================================
OS_PLATFORM=`uname -s`

OLD_LANG=$LANG
LANG=en
export LANG


#*******************************************************************************
# Common functions               
#*******************************************************************************
SUPPORTTYPE=NORMAL


#CMD_CURRENT_DIR=`pwd`
#SUPPORTDIR=$CMD_CURRENT_DIR/eassupport

#mkdir -p $SUPPORTDIR/OS

#cd $SUPPORTDIR

if [ -f admin.sh ] 
then
  cd diag/eassupport
else
  cd eassupport
fi
  
  #****************************************************************************************************************************************
  #  Gather Operation System Information ---------------------------AIX              
  #****************************************************************************************************************************************
  if [ $OS_PLATFORM = "AIX" ]
  then
  	echo Execute: prtconf                                                               >> OS/sysconfig
  	prtconf                                                                             >> OS/sysconfig
  	
  	echo Execute: date                                                                  >> OS/system  # Date and time
                  date                                                                  >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: hostname                                                              >> OS/system  # Host name
                  hostname                                                              >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: uname -a                                                              >> OS/system  # Machine information & OS level
                  uname -a                                                              >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: oslevel                                                               >> OS/system  # AIX version
                  oslevel                                                               >> OS/system
    echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: oslevel -s                                                            >> OS/system  # AIX SP
                  oslevel -s                                                            >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: bootinfo -K                                                           >> OS/system  # 32-bit vs 64-bit
                  bootinfo -K                                                           >> OS/system
    echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: bootinfo -y                                                           >> OS/system  # Hardware 32-bit or 64-bit
                  bootinfo -y                                                           >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: bootinfo -m                                                           >> OS/system  # Machine model
                  bootinfo -m                                                           >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: bootinfo -T                                                           >> OS/system  # Machine type
                  bootinfo -T                                                           >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: bootinfo -r                                                           >> OS/system  # Memory
                  bootinfo -r                                                           >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: lsattr -El sys0                                                       >> OS/system  # System Parameters
                  lsattr -El sys0                                                       >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: lsps -s                                                               >> OS/system  # Paging space summary
                  lsps -s                                                               >> OS/system
    echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: svmon -G                                                              >> OS/system  # System Memory used
                  svmon -G                                                              >> OS/system
    echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: svmon -Pt 10                                                          >> OS/system  # Top 10 Memory used
                  svmon -Pt 10                                                          >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: lsps -a                                                               >> OS/system  # Paging space details
                  lsps -a                                                               >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: df -k                                                                 >> OS/system  # File systems, space
                  df -k                                                                 >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: ulimit -a                                                             >> OS/system  # Process limits
                  ulimit -a                                                             >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: /usr/samples/kernel/vmtune                                            >> OS/system  # Kernel parameters
    [ -f /usr/samples/kernel/vmtune ] && /usr/samples/kernel/vmtune                     >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: vmstat                                                                >> OS/system  # Virtual memory information
                  vmstat                                                                >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: iostat                                                                >> OS/system  # I/O statistics
                  iostat                                                                >> OS/system
    echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: instfix -i \| grep AIX_ML                                             >> OS/system  # AIX maintenance level
                  instfix -i | grep AIX_ML                                              >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: lscfg                                                                 >> OS/system  # System hardware
                  lscfg                                                                 >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: lsdev -C -S a                                                         >> OS/system  # System hardware
                  lsdev -C -S a                                                         >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: bindprocessor -q                                                      >> OS/system  # Processors
                  bindprocessor -q                                                      >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: lsdev -Cc disk                                                        >> OS/system  # Physical disk information
                  lsdev -Cc disk                                                        >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: lspv                                                                  >> OS/system  # Physical disk information
                  lspv                                                                  >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: lsvg                                                                  >> OS/system  # Volume groups
                  lsvg                                                                  >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
    echo Execute: lsfs                                                                  >> OS/system  # File systems
                  lsfs                                                                  >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
    echo Execute: lsattr -El sys0                                                       >> OS/system  # System limits, settings
                  lsattr -El sys0                                                       >> OS/system
    echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: lssrc -a                                                              >> OS/system  # Subsystem status
                  lssrc -a                                                              >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: lsuser ALL                                                            >> OS/system  # User accounts
                  lsuser ALL                                                            >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: lsgroup ALL                                                           >> OS/system  # Groups
                  lsgroup ALL                                                           >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: lslicense                                                             >> OS/system  # Licenced users
                  lslicense                                                             >> OS/system
    
  	echo Execute: errpt -a                                                              >> OS/errpt  # Error report
                  errpt -a                                                              >> OS/errpt
  	
    echo Execute: ps -ef                                                                >> OS/all_task  # Processes
                  ps -ef                                                                >> OS/all_task
    
    echo Execute: ps aux \|sort -rn +2 \|head -10                                         >> OS/top10_cpu
                  ps aux |sort -rn +2 |head -10                                         >> OS/top10_cpu
                  
    echo Execute: netpmon -v                                                            >> OS/netpmon
    							netpmon -v                                                            >> OS/netpmon 2>&1
    echo "----------------------------------------------------------------------------" >> OS/netpmon
    sleep 5
    echo Execute: trcstop                                                               >> OS/netpmon
                  trcstop                                                               >> OS/netpmon 2>&1
    
    echo Execute: ps aux \|sort -rn +3 \|head -10                                         >> OS/top10_memory
                  ps aux |sort -rn +3 |head -10                                         >> OS/top10_memory
                              
    echo Execute: env                                                                   >> OS/env
                  env                                                                   >> OS/env
                  
    mkdir -p OS/etc
    cp -p /etc/environment OS/etc
    cp -p /etc/filesystems OS/etc
    cp -p /etc/hosts OS/etc
    cp -p /etc/inittab OS/etc
    cp -p /etc/protocols OS/etc
    cp -p /etc/services OS/etc
    cp -p /etc/shells OS/etc
    
    mkdir -p OS/var/adm/
    cp -p /var/adm/messages OS/var/adm/
    
    last -n 100 >> OS/var/adm/login
    
    alog -o -t boot >> OS/alog_boot
    alog -o -t console >> OS/alog_console
    alog -o -t cfg >> OS/alog_cfg
    alog -o -t dumpsymp >> OS/alog_dumpsymp
    
    echo Execute: hostname                                                              >> OS/network
                  hostname                                                              >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: netstat -i                                                            >> OS/network
                  netstat -i                                                            >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: netstat -in                                                           >> OS/network
                  netstat -in                                                           >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: netstat -rv                                                           >> OS/network
                  netstat -rv                                                           >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: ifconfig -a                                                           >> OS/network
                  ifconfig -a                                                           >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: showmount -e                                                          >> OS/network
                  showmount -e                                                          >> OS/network 2>&1
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: no -a                                                                 >> OS/network
                  no -a                                                                 >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: cat /etc/resolv.conf                                                  >> OS/network
  	[ -f /etc/resolv.conf ]&& cat /etc/resolv.conf                                      >> OS/network
    echo "----------------------------------------------------------------------------" >> OS/network
    echo Execute: nslookup -querytype=ANY `hostname`                                    >> OS/network
                	nslookup -querytype=ANY `hostname`                                    >> OS/network 2>&1
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: arp -a                                                                >> OS/network
                	arp -a                                                                >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: nfsstat                                                               >> OS/network
    	            nfsstat                                                               >> OS/network 
    
    echo Execute: lslpp -al                                                             >> OS/software
                  lslpp -al                                                             >> OS/software
                  
    echo Execute: instfix -i                                                            >> OS/instfix
                  instfix -i                                                            >> OS/instfix
                  
    echo Execute: /usr/java14/bin/java -version                                         >> OS/javasoft
    if [ -f /usr/java14/bin/java ] 
    then
     /usr/java14/bin/java -version                                                      >> OS/javasoft 2>&1
    else
    echo "/usr/java14/bin/java not found!"                                              >> OS/javasoft
    fi
    echo "----------------------------------------------------------------------------" >> OS/javasoft
    echo Execute: /usr/java14_64/bin/java -version                                      >> OS/javasoft
    if [ -f /usr/java14_64/bin/java ]
    then
     /usr/java14_64/bin/java -version                                                   >> OS/javasoft 2>&1
    else
    echo "/usr/java14_64/bin/java not found!"                                           >> OS/javasoft
    fi
    echo "----------------------------------------------------------------------------" >> OS/javasoft
    echo Execute: /usr/java5/bin/java -version                                          >> OS/javasoft
    if [ -f /usr/java5/bin/java ] 
    then
     /usr/java5/bin/java -version                                                       >> OS/javasoft 2>&1
    else
     echo "/usr/java5/bin/java not found!"                                              >> OS/javasoft
    fi
    echo "----------------------------------------------------------------------------" >> OS/javasoft
    echo Execute: /usr/java5_64/bin/java -version                                       >> OS/javasoft
    if [ -f /usr/java5_64/bin/java ]
    then
     /usr/java5_64/bin/java -version                                                    >> OS/javasoft 2>&1
    else
     echo "/usr/java5_64/bin/java not found!"                                           >> OS/javasoft
    fi
    echo "----------------------------------------------------------------------------" >> OS/javasoft
    
  #****************************************************************************************************************************************
  #  Gather Operation System Information ---------------------------HPUX              
  #****************************************************************************************************************************************
  elif [ $OS_PLATFORM = "HP-UX" ]
  then
    echo Execute: date                                                                  >> OS/system  # /Date and time
  	              date                                                                  >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: hostname                                                              >> OS/system  # /Host name
    	            hostname                                                              >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: uname -a                                                              >> OS/system  # /Machine information & OS level
   		            uname -a                                                              >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: model                                                                 >> OS/system  # /Machine model
    	            model                                                                 >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: swapinfo -ta                                                          >> OS/system  # /Paging space information
    	            swapinfo -ta                                                          >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: bdf                                                                   >> OS/system  # /File systems, space
    	            bdf                                                                   >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: ulimit -f                                                             >> OS/system  # /Process limits
    	            ulimit -f                                                             >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: sysdef                                                                >> OS/system  # /System definition
    	            sysdef                                                                >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: vmstat                                                                >> OS/system  # /Virtual memory information
      	          vmstat                                                                >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: iostat                                                                >> OS/system  # /I/O statistics
    	            iostat                                                                >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: ioscan -fCprocessor                                                   >> OS/system  # /Processors
    	            ioscan -fCprocessor                                                   >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: ps -ef                                                                >> OS/system  # /Processes
    	            ps -ef                                                                >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: ioscan                                                                >> OS/system  # /I/O scan
    	            ioscan                                                                >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: kctune                                                                >> OS/system  # kernel params
    	            kctune                                                                >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
    echo Execute: hostname                                                              >> OS/network
  	              hostname                                                              >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: lanscan                                                               >> OS/network
  	              lanscan                                                               >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: netstat -i                                                            >> OS/network
  		            netstat -i                                                            >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: netstat -in                                                           >> OS/network
  	              netstat -in                                                           >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: netstat -rv                                                           >> OS/network
  	              netstat -rv                                                           >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	lanscan -i |
  	  cut -f 1 -d ' ' |
  	  while read Interface
        do
  	      echo "-----------------------------"                                          >> OS/network
  	      echo Execute: ifconfig $Interface                                             >> OS/network
  	                    ifconfig $Interface                                             >> OS/network
  	    done
  	echo "-----------------------------"                                                >> OS/network
  	echo Execute: ifconfig lo0                                                          >> OS/network
  	              ifconfig lo0                                                          >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: ndd -get /dev/tcp tcp_time_wait_interval                              >> OS/network
  	              ndd -get /dev/tcp tcp_time_wait_interval                              >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: ndd -get /dev/tcp tcp_fin_wait_2_timeout                              >> OS/network
  	              ndd -get /dev/tcp tcp_fin_wait_2_timeout                              >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: ndd -get /dev/tcp tcp_keepalive_interval                              >> OS/network
  	              ndd -get /dev/tcp tcp_keepalive_interval                              >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: showmount -e                                                          >> OS/network
  	              showmount -e                                                          >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: cat /etc/resolv.conf                                                  >> OS/network
  	              cat /etc/resolv.conf                                                  >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: nslookup -querytype=ANY `hostname`                                    >> OS/network
  	              nslookup -querytype=ANY `hostname`                                    >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: arp -a                                                                >> OS/network
  	              arp -a                                                                >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: nfsstat                                                               >> OS/network
  	              nfsstat                                                               >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: cat /etc/resolv.conf                                                  >> OS/network
  	[ -f /etc/resolv.conf ]&& cat /etc/resolv.conf                                      >> OS/network
  	
    export TERM=vt100
    echo Execute: top -d 1                                                              >> OS/all_task  # Processes
    top -d 1                                                                            >> OS/all_task 
     
    echo Execute: env                                                                   >> OS/env
                  env                                                                   >> OS/env
    mkdir -p OS/etc
    cp -p  /etc/hosts OS/etc
    cp -p  /etc/protocols OS/etc
    cp -p  /etc/services OS/etc
    cp -p  /etc/TIMEZONE OS/etc
    cp -p  /etc/rc.config.d/netconf OS/etc
    cp -p  /etc/nsswitch.conf OS/etc
    cp -p  /etc/rc.config.d/nddconf OS/etc
    
    mkdir -p OS/var/adm/syslog/
    cp -p  /var/adm/syslog/*.log OS/var/adm/syslog/
    cp -p  /var/adm/shutdownlog  OS/var/adm/
    mkdir -p OS/var/adm/sw/
    cp -p  /var/adm/sw/*.log  OS/var/adm/sw/  
    
    swlist -l fileset -a patch_state *.*,c=patch | grep -v superseded                   >> OS/patches
    
    swlist                                                                              >> OS/software
    
    echo Execute: /opt/java1.4/bin/java -version                                        >> OS/javasoft
    if [ -f /opt/java1.4/bin/java ] 
    then
     /opt/java1.4/bin/java -version                                                     >> OS/javasoft 2>&1
    else
     echo "/opt/java1.4/bin/java not found!"                                            >> OS/javasoft
    fi
    echo "----------------------------------------------------------------------------" >> OS/javasoft
    echo Execute: /opt/java1.5/bin/java -version                                        >> OS/javasoft
    if [ -f /opt/java1.5/bin/java ]
    then
     /opt/java1.5/bin/java -version                                                     >> OS/javasoft 2>&1
    else
     echo "/opt/java1.5/bin/java not found!"                                            >> OS/javasoft
    fi
  
  
  #****************************************************************************************************************************************
  #  Gather Operation System Information ---------------------------SunOS Solaris              
  #****************************************************************************************************************************************
  elif [ $OS_PLATFORM = "SunOS" ]
  then
    echo Execute: date                                                                  >> OS/system  # Date and time
  	              date                                                                  >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: hostname                                                              >> OS/system  # Host name
    	            hostname                                                              >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: uname -a                                                              >> OS/system  # Machine information & OS level
    	            uname -a                                                              >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: showrev                                                               >> OS/system  # High level summary of the system
    	            showrev                                                               >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: swap -s                                                               >> OS/system  # Swap space summary
    	            swap -s                                                               >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: swap -l                                                               >> OS/system  # Swap space list
    	            swap -l                                                               >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: df -k                                                                 >> OS/system  # File systems, space
    	            df -k                                                                 >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: ulimit -a                                                             >> OS/system  # Process limits
  	              ulimit -a                                                             >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: sysdef                                                                >> OS/system  # System definition
  	              sysdef                                                                >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: vmstat                                                                >> OS/system  # Virtual memory information
  	              vmstat                                                                >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: iostat                                                                >> OS/system  # I/O statistics
  	              iostat                                                                >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: iostat -En                                                            >> OS/system  # I/O errors
  	              iostat -En                                                            >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: isainfo -v                                                            >> OS/system  # Instruction set architectures
    	            isainfo -v                                                            >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: isainfo -b                                                            >> OS/system  # Instruction set architectures
  	              isainfo -b                                                            >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: psrinfo -v                                                            >> OS/system  # Processors
  	              psrinfo -v                                                            >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: ps -ef                                                                >> OS/system  # Processes
    	            ps -ef                                                                >> OS/system
    	            
  	echo "----------------------------------------------------------------------------" >> OS/prtconf
  	echo Execute: prtconf                                                               >> OS/prtconf  # Basic system information
    	            prtconf                                                               >> OS/prtconf
  
    echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: hostname                                                              >> OS/network
  	              hostname                                                              >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: netstat -i                                                            >> OS/network
  	              netstat -i                                                            >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: netstat -in                                                           >> OS/network
  	              netstat -in                                                           >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: netstat -rv                                                           >> OS/network
  	              netstat -rv                                                           >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: ifconfig -a                                                           >> OS/network
  	              ifconfig -a                                                           >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: ndd -get /dev/tcp tcp_close_wait_interval                             >> OS/network
  	              ndd -get /dev/tcp tcp_close_wait_interval                             >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: ndd -get /dev/tcp tcp_fin_wait_2_flush_interval                       >> OS/network
  	              ndd -get /dev/tcp tcp_fin_wait_2_flush_interval                       >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: ndd -get /dev/tcp tcp_keepalive_interval                              >> OS/network
  	              ndd -get /dev/tcp tcp_keepalive_interval                              >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: showmount -e                                                          >> OS/network
  	              showmount -e                                                          >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: cat /etc/resolv.conf                                                  >> OS/network
  	              cat /etc/resolv.conf                                                  >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: nslookup -querytype=ANY `hostname`                                    >> OS/network
  	              nslookup -querytype=ANY `hostname`                                    >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: arp -a                                                                >> OS/network
  	              arp -a                                                                >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: nfsstat                                                               >> OS/network
  	              nfsstat                                                               >> OS/network
    
    pkginfo                                                                             >> OS/software
    patchadd -p                                                                         >> OS/patches 2>&1
    
    echo Execute: env                                                                   >> OS/env
                  env                                                                   >> OS/env
    mkdir -p OS/etc
    cp -p  /etc/hosts OS/etc
    cp -p  /etc/protocols OS/etc
    cp -p  /etc/services OS/etc
    cp -p  /etc/system OS/etc
    cp -p  /etc/TIMEZONE OS/etc
      
    mkdir -p OS/var/adm/
    cp -p  /var/adm/messages OS/var/adm/
    
    echo Execute: /usr/j2se/bin/java -fullversion                                       >> OS/javasoft
                  /usr/j2se/bin/java -fullversion                                       >> OS/javasoft
    
  #****************************************************************************************************************************************
  #  Gather Operation System Information ---------------------------Linux              
  #****************************************************************************************************************************************
  elif [ $OS_PLATFORM = "Linux" ]
  then
    echo Execute: uname -r                                                              >> OS/kernel
                  uname -r                                                              >> OS/kernel
    echo "----------------------------------------------------------------------------" >> OS/kernel
    echo Execute: sysctl -a                                                             >> OS/kernel
    							sysctl -a                                                             >> OS/kernel
    echo "----------------------------------------------------------------------------" >> OS/kernel
  	echo Execute: lsb_release -a                                                        >> OS/kernal 2>&1
  			
    echo Execute: date                                                                  >> OS/system  # Date and time
  	              date                                                                  >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: hostname                                                              >> OS/system  # Host name
  	              hostname                                                              >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: uname -a                                                              >> OS/system  # Machine information & OS level
  	              uname -a                                                              >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: cat /proc/meminfo                                                     >> OS/system  # Memory and paging space info
  	              cat /proc/meminfo                                                     >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: free                                                                  >> OS/system  # Memory and paging space info
  	              free                                                                  >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: df -k                                                                 >> OS/system  # File systems, space
  	              df -k                                                                 >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: ulimit -a                                                             >> OS/system  # Process limits
  	              ulimit -a                                                             >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: vmstat                                                                >> OS/system  # Virtual memory information
  	              vmstat                                                                >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: iostat                                                                >> OS/system  # I/O statistics
  	              iostat                                                                >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: cat /proc/cpuinfo                                                     >> OS/system  # Processors
  	              cat /proc/cpuinfo                                                     >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: ps -ef                                                                >> OS/system  # Processes
  	              ps -ef                                                                >> OS/system
  	echo "----------------------------------------------------------------------------" >> OS/system
  	echo Execute: cat /proc/pci                                                         >> OS/system  # Devices
  	              cat /proc/pci                                                         >> OS/system
  	              
  	echo Execute: top -b -n 10                                                          >> OS/top  # Processes
  	              top -b -n 10                                                          >> OS/top
  	              
    echo Execute: hostname                                                              >> OS/network
  	              hostname                                                              >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: lanscan                                                               >> OS/network
  	              lanscan                                                               >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: netstat -i                                                            >> OS/network
  	              netstat -i                                                            >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: netstat -in                                                           >> OS/network
  	              netstat -in                                                           >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: netstat -rv                                                           >> OS/network
  	              netstat -rv                                                           >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: ifconfig -a                                                           >> OS/network
  	              ifconfig -a                                                           >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: cat /proc/sys/net/ipv4/tcp_keepalive_time                             >> OS/network
  	              cat /proc/sys/net/ipv4/tcp_keepalive_time                             >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: showmount -e                                                          >> OS/network
  	              showmount -e                                                          >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: cat /etc/resolv.conf                                                  >> OS/network
  	              cat /etc/resolv.conf                                                  >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: nslookup -querytype=ANY `hostname`                                 >> OS/network
  	              nslookup -querytype=ANY `hostname`                                 >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: arp -a                                                                >> OS/network
  	              arp -a                                                                >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	echo Execute: nfsstat                                                               >> OS/network
  	              nfsstat                                                               >> OS/network
  	echo "----------------------------------------------------------------------------" >> OS/network
  	
  	rpm -qa                                                                             >> OS/software 2>&1
  	
  	echo Execute: env                                                                   >> OS/env
                  env                                                                   >> OS/env
    mkdir -p OS/etc
    cp -p  /etc/hosts OS/etc
    cp -p  /etc/protocols OS/etc
    cp -p  /etc/services OS/etc
    
    mkdir -p OS/var/log/
    cp -p  /var/log/messages OS/var/log/
    cp -p  /var/log/secure OS/var/log/
    cp -p  /var/log/boot.log OS/var/log/
    cp -p  /var/log/dmesg OS/var/log/
    
  
  #****************************************************************************************************************************************
  #  Gather Operation System Information ---------------------------i5/os(OS400)              
  #****************************************************************************************************************************************
  elif [ $OS_PLATFORM = "OS400" ]
  then
    echo "Gather information on OS400 platform......"
  
  else
  	echo "[$OS_PLATFORM] is not supported!"
  fi


LANG=$OLD_LANG
export LANG
