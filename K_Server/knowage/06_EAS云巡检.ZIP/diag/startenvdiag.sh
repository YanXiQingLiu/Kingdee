#!/bin/sh
#===============================================================================
# SCRIPT    : os.sh
# AUTHOR    : pound_wu
# Date      : 2011-10-31
# REV       : 1.2
# PLATFORM  : AIX HPUX Linux Solaris I5/OS(OS400)
# PURPOSE   : This script is used for collect EAS environment information.
# 
# Copyright(c) 1993-2011 Kingdee Co.,Ltd.
# All Rights Reserved 
#===============================================================================
OS_PLATFORM=`uname -s`

OLD_LANG=$LANG
LANG=en
export LANG

if [ -f "../../server/bin/set-server-env.sh" ] 
then
	SUPPORTTYPE=server
	. "../../server/bin/set-server-env.sh"
elif [ -f "../client/bin/set-client-env.sh" ]
then
  SUPPORTTYPE=client
  . "../client/bin/set-client-env.sh"
elif [ -f "./set-diag-env.sh" ]
then
  SUPPORTTYPE=database
  . "./set-diag-env.sh"
fi

if [ $WAS_SERVER_HOME ]
then
    JAVA_HOME=$WAS_SERVER_HOME/java
    export JAVA_HOME
fi

if [ $WLS_SERVER_HOME ]
then
    JAVA_VENDOR=
    export JAVA_VENDOR
    . "$WLS_SERVER_HOME/bin/setWLSEnv.sh"
fi

if [ -d "./download/plugin/" ] 
then
mv -f ${PWD}/download/plugin/* ${PWD}/plugins
fi
if [ -d "./download/server" ] 
then
mv -f ${PWD}/download/server/* ${PWD}/lib/server
fi
if [ -d "./download/client" ] 
then
mv -f ${PWD}/download/client/* ${PWD}/lib/client
fi
if [ -d "${PWD}/download/config" ] 
then
mv -f ${PWD}/download/config/* ${PWD}/config
fi


ENVCLASSPATH=./lib/client/consultant_client.jar:./lib/server/consultant.jar:./lib/server/apusicversion.jar:./lib/server/dom4j-1.6.1.jar:./lib/server/jxl.jar:./lib/server/jaxen-1.1.1.jar:./lib/server/logback-classic-0.9.28.jar:./lib/server/logback-core-0.9.28.jar:./lib/server/logo_resource_ico.jar:./lib/server/netty-3.2.4.Final.jar:./lib/server/resource_1.0.0.zip:./lib/server/simple-xml-2.5.3.jar:./lib/server/slf4j-api-1.6.1.jar:.lib/client/consultant_client.jar:./plugins/appapusic_1.0.0.jar:./plugins/appwas_1.0.0.jar:./plugins/appweblogic_1.0.0.jar:./plugins/eas_1.0.0.jar:./plugins/ibmjdk_1.0.0.jar:./plugins/sunjdk_1.0.0.jar:./plugins/os_aix_1.0.0.jar:./plugins/os_window_1.0.0.jar:./plugins/os_linux_1.0.0.jar:./plugins/oracledb_1.0.0.jar:./lib/server/ctrl-common.jar:./lib/server/ctrl-commonui.jar:./lib/server/ctrl-kdtable.jar:./lib/server/ctrl-kingdeelfm.jar:./lib/server/ctrl-swing.jar:./lib/server/eas_resource_common_ico.jar:./lib/server/eas_resource_firstload_ico.jar:./lib/server/bcmail-jdk15-1.46.jar:./lib/server/bcprov-jdk15-1.46.jar:./lib/server/bctsp-jdk15-1.46.jar:./lib/server/ctrl-kdf.jar:./lib/server/classes12.jar:./lib/server/commons-io-2.0.1.jar:./lib/server/commons-lang-2.6.jar:./lib/server/db2jcc.jar:./lib/server/fast-md5.jar:./lib/server/jtds-1.2.jar:./lib/server/db2jcc_license_cu.jar:./lib/server/ksql.jar:./lib/server/log4j-1.2.6.jar:./lib/server/commons-codec-1.3.jar:./lib/server/commons-httpclient-3.1-rc1.jar:./lib/server/commons-logging-1.1.jar:$EAS_HOME/admin/lib/foxtrot.jar:$EAS_HOME/server/lib/server/bos/license-server.jar:$EAS_HOME/server/lib/common/bos/uimodel.jar:$EAS_HOME/server/lib/server/bos/eas_common-client.jar:$EAS_HOME/server/lib/common/bos/common.jar:$EAS_HOME/server/lib/client/bos/bd_org-client.jar:$EAS_HOME/server/lib/server/bos/eas_framework-server.jar:$EAS_HOME/server/lib/server/bos/bs_uiframe-server.jar:$EAS_HOME/server/lib/common/bos/metadata.jar:$EAS_HOME/server/lib/server/eas/bd_org_ext-server.jar:$EAS_HOME/server/lib/common/bos/ormrpc.jar:$EAS_HOME/server/lib/common/trd/jdom-b9.jar:$EAS_HOME/server/lib/common/trd/tika-app-4cp-1.0.jar:$EAS_HOME/admin/lib/ant.jar



[ -f $JAVA_HOME/bin/java ] && $JAVA_HOME/bin/java -Xms64m -Xmx512m  -cp $ENVCLASSPATH  -DEAS_HOME=$EAS_HOME  -DDIAG_HOME=$DIAG_HOME -Deas.deploy=$EAS_HOME/server/profiles/server1/config  com.kingdee.bos.consultant.client.ui.ConsultantMainFrame -configuration ./config -clean


LANG=$OLD_LANG
export LANG

