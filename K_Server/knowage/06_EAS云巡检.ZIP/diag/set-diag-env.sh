#!/bin/sh
# ===============================================================================
# SCRIPT   :	set-server-env.bat
# AUTHOR   : klaus
# Date     :	2012-05-30
# REV      :	7.5
# PLATFORM :	Windows
# PURPOSE  :	This script is used to define EAS diag tools runtime variavables.
# 
# Copyright(c) 2012 Kingdee Co.,Ltd.
# All Rights Reserved 
# ===============================================================================

DIAG_HOME=/usr/diag
JAVA_HOME=/usr/javaHome
export DIAG_HOME
export JAVA_HOME
