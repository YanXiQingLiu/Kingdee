﻿解压到目录xxServer(实例目录)/bin,进入该bin目录。
windows下执行命令：
chadminpass newpassword
newpassword为要设置的密码，要求至少8位，包括大小写字母、数字、特殊字符

linux下执行命令：
./chadminpass newpassword
newpassword为要设置的密码，要求至少8位，包括大小写字母、数字、特殊字符
如果没有执行权限，请使用如下命令赋予脚本执行权限
chmod +x chadminpass
chmod +x setenvchadminpass